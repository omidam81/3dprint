﻿namespace UV_DLP_3D_Printer.GUI.Controls.ManualControls
{
    partial class ctlStandardManual
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ctlParameter1 = new UV_DLP_3D_Printer.GUI.CustomGUI.ctlParameter();
            this.ctlParamZrate = new UV_DLP_3D_Printer.GUI.CustomGUI.ctlParameter();
            this.ctlRFrame1 = new UV_DLP_3D_Printer.GUI.CustomGUI.ctlRFrame();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblTitle.ForeColor = System.Drawing.Color.Black;
            this.lblTitle.Location = new System.Drawing.Point(34, 15);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(297, 38);
            this.lblTitle.TabIndex = 67;
            this.lblTitle.Text = "Standard Manual Controls";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.groupBox1.Location = new System.Drawing.Point(20, 62);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.groupBox1.Size = new System.Drawing.Size(482, 210);
            this.groupBox1.TabIndex = 68;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Home Printer";
            // 
            // ctlParameter1
            // 
            this.ctlParameter1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.ctlParameter1.FrameColor = System.Drawing.Color.RoyalBlue;
            this.ctlParameter1.Gapx = 0;
            this.ctlParameter1.Gapy = 0;
            this.ctlParameter1.GLBackgroundImage = null;
            this.ctlParameter1.GLVisible = false;
            this.ctlParameter1.GuiAnchor = null;
            this.ctlParameter1.Location = new System.Drawing.Point(18, 351);
            this.ctlParameter1.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.ctlParameter1.Name = "ctlParameter1";
            this.ctlParameter1.ReturnValues = new float[] {
        0F,
        0F,
        0F,
        0F};
            this.ctlParameter1.Size = new System.Drawing.Size(422, 58);
            this.ctlParameter1.StyleName = null;
            this.ctlParameter1.TabIndex = 69;
            this.ctlParameter1.Title = "Move printing (mm):";
            this.ctlParameter1.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // ctlParamZrate
            // 
            this.ctlParamZrate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.ctlParamZrate.FrameColor = System.Drawing.Color.RoyalBlue;
            this.ctlParamZrate.Gapx = 0;
            this.ctlParamZrate.Gapy = 0;
            this.ctlParamZrate.GLBackgroundImage = null;
            this.ctlParamZrate.GLVisible = false;
            this.ctlParamZrate.GuiAnchor = null;
            this.ctlParamZrate.Location = new System.Drawing.Point(20, 286);
            this.ctlParamZrate.Margin = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.ctlParamZrate.Name = "ctlParamZrate";
            this.ctlParamZrate.ReturnValues = new float[] {
        0F,
        0F,
        0F,
        0F};
            this.ctlParamZrate.Size = new System.Drawing.Size(420, 58);
            this.ctlParamZrate.StyleName = null;
            this.ctlParamZrate.TabIndex = 1;
            this.ctlParamZrate.Title = "Move feeding (mm):";
            this.ctlParamZrate.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // ctlRFrame1
            // 
            this.ctlRFrame1.Location = new System.Drawing.Point(6, 6);
            this.ctlRFrame1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.ctlRFrame1.Name = "ctlRFrame1";
            this.ctlRFrame1.Size = new System.Drawing.Size(518, 432);
            this.ctlRFrame1.TabIndex = 72;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(18, 31);
            this.button1.Margin = new System.Windows.Forms.Padding(6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(452, 44);
            this.button1.TabIndex = 6;
            this.button1.Text = "Home print heads";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(18, 87);
            this.button2.Margin = new System.Windows.Forms.Padding(6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(452, 44);
            this.button2.TabIndex = 7;
            this.button2.Text = "Home feed ";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(18, 143);
            this.button3.Margin = new System.Windows.Forms.Padding(6);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(452, 44);
            this.button3.TabIndex = 8;
            this.button3.Text = "Home print";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.button4.Location = new System.Drawing.Point(456, 293);
            this.button4.Margin = new System.Windows.Forms.Padding(6);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(55, 44);
            this.button4.TabIndex = 9;
            this.button4.Text = "Ok";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.button5.Location = new System.Drawing.Point(456, 358);
            this.button5.Margin = new System.Windows.Forms.Padding(6);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(55, 44);
            this.button5.TabIndex = 73;
            this.button5.Text = "Ok";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // ctlStandardManual
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.ctlParameter1);
            this.Controls.Add(this.ctlParamZrate);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.ctlRFrame1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ctlStandardManual";
            this.Size = new System.Drawing.Size(559, 458);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox groupBox1;
        private CustomGUI.ctlParameter ctlParamZrate;
        private CustomGUI.ctlParameter ctlParameter1;
        private CustomGUI.ctlRFrame ctlRFrame1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
    }
}
