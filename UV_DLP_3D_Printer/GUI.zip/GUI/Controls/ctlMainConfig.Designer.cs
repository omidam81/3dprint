namespace UV_DLP_3D_Printer.GUI.Controls
{
    partial class ctlMainConfig
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.ctlMachineConfigView = new UV_DLP_3D_Printer.GUI.CustomGUI.ctlTitle();
            this.ctlSliceProfileConfig = new UV_DLP_3D_Printer.GUI.CustomGUI.ctlTitle();
            this.ctlMachineConfigView1 = new UV_DLP_3D_Printer.GUI.CustomGUI.ctlImageButtonEx();
            this.ctlSliceProfileConfig1 = new UV_DLP_3D_Printer.GUI.CustomGUI.ctlImageButtonEx();
            this.ctlMachineConfig1 = new UV_DLP_3D_Printer.GUI.Controls.ctlMachineConfig();
            this.ctlToolpathGenConfig1 = new UV_DLP_3D_Printer.GUI.Controls.ctlToolpathGenConfig();
            this.pnlMachineConfig = new System.Windows.Forms.Panel();
            this.pnlToolpathGenConfig = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1.SuspendLayout();
            this.pnlMachineConfig.SuspendLayout();
            this.pnlToolpathGenConfig.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanel1.Controls.Add(this.ctlMachineConfigView);
            this.flowLayoutPanel1.Controls.Add(this.ctlSliceProfileConfig);
            this.flowLayoutPanel1.Controls.Add(this.ctlMachineConfigView1);
            this.flowLayoutPanel1.Controls.Add(this.ctlSliceProfileConfig1);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(972, 50);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // ctlMachineConfigView
            // 
            this.ctlMachineConfigView.BackColor = System.Drawing.Color.RoyalBlue;
            this.ctlMachineConfigView.Checked = false;
            this.ctlMachineConfigView.CheckImage = global::UV_DLP_3D_Printer.Properties.Resource_s.buttChecked;
            this.ctlMachineConfigView.Gapx = 0;
            this.ctlMachineConfigView.Gapy = 0;
            this.ctlMachineConfigView.GLBackgroundImage = null;
            this.ctlMachineConfigView.GLImage = null;
            this.ctlMachineConfigView.GLVisible = false;
            this.ctlMachineConfigView.GuiAnchor = null;
            this.ctlMachineConfigView.HorizontalAnchor = UV_DLP_3D_Printer.GUI.CustomGUI.ctlAnchorable.AnchorTypes.None;
            this.ctlMachineConfigView.Image = global::UV_DLP_3D_Printer.Properties.Resource_s.buttMachineConfig;
            this.ctlMachineConfigView.Location = new System.Drawing.Point(3, 3);
            this.ctlMachineConfigView.Name = "ctlMachineConfigView";
            this.ctlMachineConfigView.OnClickCallback = "ClickViewConfMachine";
            this.ctlMachineConfigView.Size = new System.Drawing.Size(84, 40);
            this.ctlMachineConfigView.StyleName = null;
            this.ctlMachineConfigView.TabIndex = 1;
            this.ctlMachineConfigView.Text = "Configure Machine";
            this.ctlMachineConfigView.VerticalAnchor = UV_DLP_3D_Printer.GUI.CustomGUI.ctlAnchorable.AnchorTypes.None;
            this.ctlMachineConfigView.Visible = false;
            // 
            // ctlSliceProfileConfig
            // 
            this.ctlSliceProfileConfig.BackColor = System.Drawing.Color.RoyalBlue;
            this.ctlSliceProfileConfig.Checked = false;
            this.ctlSliceProfileConfig.CheckImage = global::UV_DLP_3D_Printer.Properties.Resource_s.buttChecked;
            this.ctlSliceProfileConfig.Gapx = 0;
            this.ctlSliceProfileConfig.Gapy = 0;
            this.ctlSliceProfileConfig.GLBackgroundImage = null;
            this.ctlSliceProfileConfig.GLImage = null;
            this.ctlSliceProfileConfig.GLVisible = false;
            this.ctlSliceProfileConfig.GuiAnchor = null;
            this.ctlSliceProfileConfig.HorizontalAnchor = UV_DLP_3D_Printer.GUI.CustomGUI.ctlAnchorable.AnchorTypes.None;
            this.ctlSliceProfileConfig.Image = global::UV_DLP_3D_Printer.Properties.Resource_s.buttSliceConf;
            this.ctlSliceProfileConfig.Location = new System.Drawing.Point(93, 3);
            this.ctlSliceProfileConfig.Name = "ctlSliceProfileConfig";
            this.ctlSliceProfileConfig.OnClickCallback = "ClickViewSliceConfig";
            this.ctlSliceProfileConfig.Size = new System.Drawing.Size(114, 40);
            this.ctlSliceProfileConfig.StyleName = null;
            this.ctlSliceProfileConfig.TabIndex = 2;
            this.ctlSliceProfileConfig.Text = "Configure Slicing Profile";
            this.ctlSliceProfileConfig.VerticalAnchor = UV_DLP_3D_Printer.GUI.CustomGUI.ctlAnchorable.AnchorTypes.None;
            this.ctlSliceProfileConfig.Visible = false;
            // 
            // ctlMachineConfigView1
            // 
            this.ctlMachineConfigView1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(174)))), ((int)(((byte)(196)))));
            this.ctlMachineConfigView1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(174)))), ((int)(((byte)(196)))));
            this.ctlMachineConfigView1.FlatAppearance.BorderSize = 0;
            this.ctlMachineConfigView1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ctlMachineConfigView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctlMachineConfigView1.ForeColor = System.Drawing.Color.White;
            this.ctlMachineConfigView1.HoverImage = global::UV_DLP_3D_Printer.Properties.Resources.buttMachineConfig42w;
            this.ctlMachineConfigView1.Image = global::UV_DLP_3D_Printer.Properties.Resources.buttMachineConfig42;
            this.ctlMachineConfigView1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ctlMachineConfigView1.IsToggle = true;
            this.ctlMachineConfigView1.Location = new System.Drawing.Point(213, 3);
            this.ctlMachineConfigView1.MainImage = global::UV_DLP_3D_Printer.Properties.Resources.buttMachineConfig42;
            this.ctlMachineConfigView1.Name = "ctlMachineConfigView1";
            this.ctlMachineConfigView1.OnClickCallback = "ClickViewConfMachine";
            this.ctlMachineConfigView1.Size = new System.Drawing.Size(274, 46);
            this.ctlMachineConfigView1.TabIndex = 5;
            this.ctlMachineConfigView1.Text = "Configure Machine";
            this.ctlMachineConfigView1.UseVisualStyleBackColor = false;
            // 
            // ctlSliceProfileConfig1
            // 
            this.ctlSliceProfileConfig1.BackColor = System.Drawing.Color.Transparent;
            this.ctlSliceProfileConfig1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(174)))), ((int)(((byte)(196)))));
            this.ctlSliceProfileConfig1.FlatAppearance.BorderSize = 0;
            this.ctlSliceProfileConfig1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ctlSliceProfileConfig1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctlSliceProfileConfig1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(174)))), ((int)(((byte)(196)))));
            this.ctlSliceProfileConfig1.HoverImage = global::UV_DLP_3D_Printer.Properties.Resources.config2_48w;
            this.ctlSliceProfileConfig1.Image = global::UV_DLP_3D_Printer.Properties.Resources.config2_42;
            this.ctlSliceProfileConfig1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ctlSliceProfileConfig1.IsToggle = false;
            this.ctlSliceProfileConfig1.Location = new System.Drawing.Point(493, 3);
            this.ctlSliceProfileConfig1.MainImage = global::UV_DLP_3D_Printer.Properties.Resources.config2_42;
            this.ctlSliceProfileConfig1.Name = "ctlSliceProfileConfig1";
            this.ctlSliceProfileConfig1.OnClickCallback = "ClickViewSliceConfig";
            this.ctlSliceProfileConfig1.Size = new System.Drawing.Size(308, 46);
            this.ctlSliceProfileConfig1.TabIndex = 6;
            this.ctlSliceProfileConfig1.Text = "Configure Slicing Profile";
            this.ctlSliceProfileConfig1.UseVisualStyleBackColor = true;
            // 
            // ctlMachineConfig1
            // 
            this.ctlMachineConfig1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctlMachineConfig1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctlMachineConfig1.Location = new System.Drawing.Point(0, 0);
            this.ctlMachineConfig1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ctlMachineConfig1.Name = "ctlMachineConfig1";
            this.ctlMachineConfig1.Size = new System.Drawing.Size(25, 21);
            this.ctlMachineConfig1.TabIndex = 2;
            // 
            // ctlToolpathGenConfig1
            // 
            this.ctlToolpathGenConfig1.BackColor = System.Drawing.SystemColors.Control;
            this.ctlToolpathGenConfig1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctlToolpathGenConfig1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctlToolpathGenConfig1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ctlToolpathGenConfig1.Location = new System.Drawing.Point(0, 0);
            this.ctlToolpathGenConfig1.Margin = new System.Windows.Forms.Padding(4);
            this.ctlToolpathGenConfig1.Name = "ctlToolpathGenConfig1";
            this.ctlToolpathGenConfig1.Size = new System.Drawing.Size(10, 42);
            this.ctlToolpathGenConfig1.TabIndex = 1;
            // 
            // pnlMachineConfig
            // 
            this.pnlMachineConfig.Controls.Add(this.ctlMachineConfig1);
            this.pnlMachineConfig.Location = new System.Drawing.Point(22, 56);
            this.pnlMachineConfig.Name = "pnlMachineConfig";
            this.pnlMachineConfig.Size = new System.Drawing.Size(25, 21);
            this.pnlMachineConfig.TabIndex = 3;
            // 
            // pnlToolpathGenConfig
            // 
            this.pnlToolpathGenConfig.Controls.Add(this.ctlToolpathGenConfig1);
            this.pnlToolpathGenConfig.Location = new System.Drawing.Point(5, 56);
            this.pnlToolpathGenConfig.Name = "pnlToolpathGenConfig";
            this.pnlToolpathGenConfig.Size = new System.Drawing.Size(10, 42);
            this.pnlToolpathGenConfig.TabIndex = 4;
            // 
            // ctlMainConfig
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.pnlToolpathGenConfig);
            this.Controls.Add(this.pnlMachineConfig);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "ctlMainConfig";
            this.Size = new System.Drawing.Size(972, 528);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.pnlMachineConfig.ResumeLayout(false);
            this.pnlToolpathGenConfig.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private CustomGUI.ctlTitle ctlMachineConfigView;
        private CustomGUI.ctlTitle ctlSliceProfileConfig;
        private ctlToolpathGenConfig ctlToolpathGenConfig1;
        private ctlMachineConfig ctlMachineConfig1;
        private System.Windows.Forms.Panel pnlMachineConfig;
        private System.Windows.Forms.Panel pnlToolpathGenConfig;
        private CustomGUI.ctlImageButtonEx ctlMachineConfigView1;
        private CustomGUI.ctlImageButtonEx ctlSliceProfileConfig1;

    }
}
