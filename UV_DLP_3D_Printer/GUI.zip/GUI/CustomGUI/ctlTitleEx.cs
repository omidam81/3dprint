﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UV_DLP_3D_Printer.GUI.CustomGUI
{
    public partial class ctlTitleEx : ctlImageButton
    {
        public ctlTitleEx()
        {
            InitializeComponent();
        }

        public ctlImageButton Button 
        {
            get { return this; }
        }

        //protected override void OnPaint(PaintEventArgs e)
        //{
        //    base.OnPaint(e);
        //}

        //public override void ApplyStyle(GuiControlStyle ct)
        //{
        //    base.ApplyStyle(ct);
        //}
    }



}
